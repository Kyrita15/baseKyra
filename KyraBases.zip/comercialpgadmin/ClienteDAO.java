
package comercialpgadmin;
import java.sql.*;

public class ClienteDAO {
    private Connection connection;

    public ClienteDAO() {
        connection = DatabaseConnection.getConnection();
    }

    public Cliente getClienteByIdentificacion(String identificacion) throws SQLException {
        String query = "SELECT * FROM CLIENTES WHERE CLIIDENTIFICACION = ?";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, identificacion);
        ResultSet resultSet = statement.executeQuery();
        if (resultSet.next()) {
            Cliente cliente = new Cliente();
            cliente.setClicodigo(resultSet.getString("CLICODIGO"));
            cliente.setClinombre(resultSet.getString("CLINOMBRE"));
            cliente.setCliidentificacion(resultSet.getString("CLIIDENTIFICACION"));
            cliente.setClidireccion(resultSet.getString("CLIDIRECCION"));
            cliente.setClitelefono(resultSet.getString("CLITELEFONO"));
            cliente.setClicelular(resultSet.getString("CLICELULAR"));
            cliente.setCliemail(resultSet.getString("CLIEMAIL"));
            cliente.setClitipo(resultSet.getString("CLITIPO"));
            cliente.setClistatus(resultSet.getString("CLISTATUS"));
            return cliente;
        }
        return null;
    }

    public void addCliente(Cliente cliente) throws SQLException {
        String query = "INSERT INTO CLIENTES (CLICODIGO, CLINOMBRE, CLIIDENTIFICACION, CLIDIRECCION, CLITELEFONO, CLICELULAR, CLIEMAIL, CLITIPO, CLISTATUS) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, cliente.getClicodigo());
        statement.setString(2, cliente.getClinombre());
        statement.setString(3, cliente.getCliidentificacion());
        statement.setString(4, cliente.getClidireccion());
        statement.setString(5, cliente.getClitelefono());
        statement.setString(6, cliente.getClicelular());
        statement.setString(7, cliente.getCliemail());
        statement.setString(8, cliente.getClitipo());
        statement.setString(9, "ACT");  // Estado predeterminado como 'ACT'
        statement.executeUpdate();
    }

    public void deactivateCliente(String identificacion) throws SQLException {
        String query = "UPDATE CLIENTES SET CLISTATUS = 'INA' WHERE CLIIDENTIFICACION = ?";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, identificacion);
        statement.executeUpdate();
    }
}
