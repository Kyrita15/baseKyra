
package comercialpgadmin;

public class StoDetalle {
    private int id;
    private String stoSerie1;
    private String stoSerie2;
    private String stoNumFactura;
    private String fechaHora;
    private String codigoProducto;
    private String codigoCliente;
    private double cantidadProducto;
    private double precioUnitario;
    private double precioTotal;
    private double costoUnitario;
    private double costoTotal;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getStoSerie1() {
        return stoSerie1;
    }

    public void setStoSerie1(String stoSerie1) {
        this.stoSerie1 = stoSerie1;
    }

    public String getStoSerie2() {
        return stoSerie2;
    }

    public void setStoSerie2(String stoSerie2) {
        this.stoSerie2 = stoSerie2;
    }

    public String getStoNumFactura() {
        return stoNumFactura;
    }

    public void setStoNumFactura(String stoNumFactura) {
        this.stoNumFactura = stoNumFactura;
    }

    public String getFechaHora() {
        return fechaHora;
    }

    public void setFechaHora(String fechaHora) {
        this.fechaHora = fechaHora;
    }

    public String getCodigoProducto() {
        return codigoProducto;
    }

    public void setCodigoProducto(String codigoProducto) {
        this.codigoProducto = codigoProducto;
    }

    public String getCodigoCliente() {
        return codigoCliente;
    }

    public void setCodigoCliente(String codigoCliente) {
        this.codigoCliente = codigoCliente;
    }

    public double getCantidadProducto() {
        return cantidadProducto;
    }

    public void setCantidadProducto(double cantidadProducto) {
        this.cantidadProducto = cantidadProducto;
    }

    public double getPrecioUnitario() {
        return precioUnitario;
    }

    public void setPrecioUnitario(double precioUnitario) {
        this.precioUnitario = precioUnitario;
    }

    public double getPrecioTotal() {
        return precioTotal;
    }

    public void setPrecioTotal(double precioTotal) {
        this.precioTotal = precioTotal;
    }

    public double getCostoUnitario() {
        return costoUnitario;
    }

    public void setCostoUnitario(double costoUnitario) {
        this.costoUnitario = costoUnitario;
    }

    public double getCostoTotal() {
        return costoTotal;
    }

    public void setCostoTotal(double costoTotal) {
        this.costoTotal = costoTotal;
    }

    public String getNombreProducto() {
        return nombreProducto;
    }

    public void setNombreProducto(String nombreProducto) {
        this.nombreProducto = nombreProducto;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    private String nombreProducto;
    private String status;
    
}

