
package comercialpgadmin;
import java.awt.*;
import java.awt.print.*;

public class FacturaPrinter implements Printable {
    private Factura factura;

    public FacturaPrinter(Factura factura) {
        this.factura = factura;
    }

    @Override
    public int print(Graphics g, PageFormat pageFormat, int pageIndex) {
        if (pageIndex > 0) {
            return NO_SUCH_PAGE;
        }

        Graphics2D g2d = (Graphics2D) g;
        g2d.translate(pageFormat.getImageableX(), pageFormat.getImageableY());

        // Dibujar el contenido de la factura
        int y = 100;
        g.drawString("Factura", 100, y);
        y += 20;
        g.drawString("Cliente: " + factura.getCliente().getClinombre(), 100, y);
        y += 20;
        g.drawString("Cédula/NIT: " + factura.getCliente().getCliidentificacion(), 100, y);
        y += 20;
        g.drawString("Dirección: " + factura.getCliente().getClidireccion(), 100, y);
        y += 20;
        g.drawString("Teléfono: " + factura.getCliente().getClitelefono(), 100, y);
        y += 20;
        g.drawString("Email: " + factura.getCliente().getCliemail(), 100, y);
        y += 20;
        g.drawString("Fecha de Emisión: " + factura.getFechaEmision(), 100, y);
        y += 20;

        g.drawString("Productos:", 100, y);
        y += 20;

        g.drawString("Código", 100, y);
        g.drawString("Descripción", 200, y);
        g.drawString("Cantidad", 350, y);
        g.drawString("Precio Unitario", 450, y);
        g.drawString("Subtotal", 550, y);
        y += 20;

        for (ProductoFactura producto : factura.getProductos()) {
            g.drawString(producto.getProducto().getProcodigo(), 100, y);
            g.drawString(producto.getProducto().getProdescripcion(), 200, y);
            g.drawString(String.valueOf(producto.getCantidad()), 350, y);
            g.drawString(String.valueOf(producto.getPrecioUnitario()), 450, y);
            g.drawString(String.valueOf(producto.getSubtotal()), 550, y);
            y += 20;
        }

        y += 20;
        g.drawString("Subtotal: " + factura.getSubtotal(), 100, y);
        y += 20;
        g.drawString("IVA: " + factura.getIva(), 100, y);
        y += 20;
        g.drawString("Total: " + factura.getTotal(), 100, y);

        return PAGE_EXISTS;
    }

    public void printFactura() {
        PrinterJob job = PrinterJob.getPrinterJob();
        job.setPrintable(this);

        boolean doPrint = job.printDialog();
        if (doPrint) {
            try {
                job.print();
            } catch (PrinterException e) {
                e.printStackTrace();
            }
        }
    }
}
