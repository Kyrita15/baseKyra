/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package comercialpgadmin;
public class Empleado {
    private String empcodigo;
    private String empapellido1;
    private String empapellido2;
    private String empnombre1;
    private String empnombre2;
    private String empfechanacimiento;
    private String empsexo;
    private String empeemail;
    private String empdireccion;
    private String emptiposangre;
    private double empsueldo;

    public String getEmpcodigo() {
        return empcodigo;
    }

    public void setEmpcodigo(String empcodigo) {
        this.empcodigo = empcodigo;
    }

    public String getEmpapellido1() {
        return empapellido1;
    }

    public void setEmpapellido1(String empapellido1) {
        this.empapellido1 = empapellido1;
    }

    public String getEmpapellido2() {
        return empapellido2;
    }

    public void setEmpapellido2(String empapellido2) {
        this.empapellido2 = empapellido2;
    }

    public String getEmpnombre1() {
        return empnombre1;
    }

    public void setEmpnombre1(String empnombre1) {
        this.empnombre1 = empnombre1;
    }

    public String getEmpnombre2() {
        return empnombre2;
    }

    public void setEmpnombre2(String empnombre2) {
        this.empnombre2 = empnombre2;
    }

    public String getEmpfechanacimiento() {
        return empfechanacimiento;
    }

    public void setEmpfechanacimiento(String empfechanacimiento) {
        this.empfechanacimiento = empfechanacimiento;
    }

    public String getEmpsexo() {
        return empsexo;
    }

    public void setEmpsexo(String empsexo) {
        this.empsexo = empsexo;
    }

    public String getEmpeemail() {
        return empeemail;
    }

    public void setEmpeemail(String empeemail) {
        this.empeemail = empeemail;
    }

    public String getEmpdireccion() {
        return empdireccion;
    }

    public void setEmpdireccion(String empdireccion) {
        this.empdireccion = empdireccion;
    }

    public String getEmptiposangre() {
        return emptiposangre;
    }

    public void setEmptiposangre(String emptiposangre) {
        this.emptiposangre = emptiposangre;
    }

    public double getEmpsueldo() {
        return empsueldo;
    }

    public void setEmpsueldo(double empsueldo) {
        this.empsueldo = empsueldo;
    }

    public String getEmpbanco() {
        return empbanco;
    }

    public void setEmpbanco(String empbanco) {
        this.empbanco = empbanco;
    }

    public String getEmpcuenta() {
        return empcuenta;
    }

    public void setEmpcuenta(String empcuenta) {
        this.empcuenta = empcuenta;
    }

    public String getEmpstatus() {
        return empstatus;
    }

    public void setEmpstatus(String empstatus) {
        this.empstatus = empstatus;
    }
    private String empbanco;
    private String empcuenta;
    private String empstatus;
    
}
