package comercialpgadmin;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class FacturaGUI extends JFrame {
    private JTextField txtCedulaCliente;
    private JTextField txtNombreCliente;
    private JTextField txtDireccionCliente;
    private JTextField txtTelefonoCliente;
    private JTextField txtEmailCliente;
    private JTextField txtCodigoProducto;
    private JTextField txtNombreProducto;
    private JTextField txtCantidadProducto;
    private JTextField txtPrecioProducto;
    private JTextField txtSubtotal;
    private JTextField txtIva;
    private JTextField txtTotal;
    private JButton btnBuscarCliente;
    private JButton btnAgregarProducto;
    private JButton btnCrearCliente;
    private JButton btnGuardarFactura;
    private JButton btnCancelarFactura;
    private JButton btnNuevaFactura;
    private JButton btnImprimirFactura;
    private JTable tblFacturas;
    private DefaultTableModel facturasModel;
    private DefaultTableModel productosModel;
    private ClienteDAO clienteDAO;
    private ProductoDAO productoDAO;
    private FacturaDAO facturaDAO;

    public FacturaGUI() {
        clienteDAO = new ClienteDAO();
        productoDAO = new ProductoDAO();
        facturaDAO = new FacturaDAO();

        setTitle("Sistema de Facturación KyritaBD");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel panelCliente = new JPanel(new GridBagLayout());
        panelCliente.setBorder(BorderFactory.createTitledBorder("Datos del Cliente"));
        panelCliente.setBackground(new Color(255, 182, 193));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);

        gbc.gridx = 0;
        gbc.gridy = 0;
        panelCliente.add(new JLabel("Cédula/NIT del Cliente:"), gbc);

        txtCedulaCliente = new JTextField(20);
        gbc.gridx = 1;
        panelCliente.add(txtCedulaCliente, gbc);

        btnBuscarCliente = new JButton("Buscar Cliente");
        btnBuscarCliente.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                buscarCliente();
            }
        });
        gbc.gridx = 2;
        panelCliente.add(btnBuscarCliente, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        panelCliente.add(new JLabel("Nombre del Cliente:"), gbc);

        txtNombreCliente = new JTextField(20);
        txtNombreCliente.setEditable(false);
        gbc.gridx = 1;
        panelCliente.add(txtNombreCliente, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        panelCliente.add(new JLabel("Dirección del Cliente:"), gbc);

        txtDireccionCliente = new JTextField(20);
        txtDireccionCliente.setEditable(false);
        gbc.gridx = 1;
        panelCliente.add(txtDireccionCliente, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        panelCliente.add(new JLabel("Teléfono del Cliente:"), gbc);

        txtTelefonoCliente = new JTextField(20);
        txtTelefonoCliente.setEditable(false);
        gbc.gridx = 1;
        panelCliente.add(txtTelefonoCliente, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        panelCliente.add(new JLabel("Email del Cliente:"), gbc);

        txtEmailCliente = new JTextField(20);
        txtEmailCliente.setEditable(false);
        gbc.gridx = 1;
        panelCliente.add(txtEmailCliente, gbc);

        btnCrearCliente = new JButton("Crear Nuevo Cliente");
        btnCrearCliente.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                crearCliente();
            }
        });
        gbc.gridx = 2;
        gbc.gridy = 4;
        panelCliente.add(btnCrearCliente, gbc);

        JPanel panelProducto = new JPanel(new GridBagLayout());
        panelProducto.setBorder(BorderFactory.createTitledBorder("Datos del Producto"));
        panelProducto.setBackground(new Color(255, 182, 193));

        gbc.gridx = 0;
        gbc.gridy = 0;
        panelProducto.add(new JLabel("Código del Producto:"), gbc);

        txtCodigoProducto = new JTextField(20);
        gbc.gridx = 1;
        panelProducto.add(txtCodigoProducto, gbc);

        btnAgregarProducto = new JButton("Agregar Producto");
        btnAgregarProducto.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                agregarProducto();
            }
        });
        gbc.gridx = 2;
        panelProducto.add(btnAgregarProducto, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        panelProducto.add(new JLabel("Nombre del Producto:"), gbc);

        txtNombreProducto = new JTextField(20);
        txtNombreProducto.setEditable(false);
        gbc.gridx = 1;
        panelProducto.add(txtNombreProducto, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        panelProducto.add(new JLabel("Cantidad:"), gbc);

        txtCantidadProducto = new JTextField(20);
        gbc.gridx = 1;
        panelProducto.add(txtCantidadProducto, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        panelProducto.add(new JLabel("Precio Unitario:"), gbc);

        txtPrecioProducto = new JTextField(20);
        txtPrecioProducto.setEditable(false);
        gbc.gridx = 1;
        panelProducto.add(txtPrecioProducto, gbc);

        String[] columnasProductos = {"Código", "Descripción", "Cantidad", "Precio Unitario", "Subtotal"};
        productosModel = new DefaultTableModel(columnasProductos, 0);
        JTable tblProductos = new JTable(productosModel);
        JScrollPane scrollPaneProductos = new JScrollPane(tblProductos);

        JPanel panelTotales = new JPanel(new GridBagLayout());
        panelTotales.setBorder(BorderFactory.createTitledBorder("Totales"));
        panelTotales.setBackground(new Color(255, 182, 193));

        gbc.gridx = 0;
        gbc.gridy = 0;
        panelTotales.add(new JLabel("Subtotal:"), gbc);

        txtSubtotal = new JTextField(20);
        txtSubtotal.setEditable(false);
        gbc.gridx = 1;
        panelTotales.add(txtSubtotal, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        panelTotales.add(new JLabel("IVA:"), gbc);

        txtIva = new JTextField(20);
        txtIva.setEditable(false);
        gbc.gridx = 1;
        panelTotales.add(txtIva, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        panelTotales.add(new JLabel("Total:"), gbc);

        txtTotal = new JTextField(20);
        txtTotal.setEditable(false);
        gbc.gridx = 1;
        panelTotales.add(txtTotal, gbc);

        btnGuardarFactura = new JButton("Guardar Factura");
        btnGuardarFactura.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                guardarFactura();
            }
        });

        btnCancelarFactura = new JButton("Cancelar Factura");
        btnCancelarFactura.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cancelarFactura();
            }
        });

        btnNuevaFactura = new JButton("Nueva Factura");
        btnNuevaFactura.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                nuevaFactura();
            }
        });

        btnImprimirFactura = new JButton("Imprimir Factura");
        btnImprimirFactura.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                imprimirFactura();
            }
        });

        JPanel panelBotones = new JPanel();
        panelBotones.setBackground(new Color(255, 182, 193));
        panelBotones.add(btnGuardarFactura);
        panelBotones.add(btnCancelarFactura);
        panelBotones.add(btnNuevaFactura);
        panelBotones.add(btnImprimirFactura);

        // Panel de Facturas
        JPanel panelFacturas = new JPanel(new BorderLayout());
        panelFacturas.setBorder(BorderFactory.createTitledBorder("Facturas Realizadas"));
        panelFacturas.setBackground(new Color(255, 182, 193));

        String[] columnasFacturas = {"ID", "Cliente", "Fecha", "Total"};
        facturasModel = new DefaultTableModel(columnasFacturas, 0);
        tblFacturas = new JTable(facturasModel);
        JScrollPane scrollPaneFacturas = new JScrollPane(tblFacturas);

        JButton btnCargarFactura = new JButton("Cargar Factura");
        btnCargarFactura.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cargarFactura();
            }
        });

        panelFacturas.add(scrollPaneFacturas, BorderLayout.CENTER);
        panelFacturas.add(btnCargarFactura, BorderLayout.SOUTH);

        add(panelCliente, BorderLayout.NORTH);
        add(panelProducto, BorderLayout.WEST);
        add(scrollPaneProductos, BorderLayout.CENTER);
        add(panelTotales, BorderLayout.SOUTH);
        add(panelBotones, BorderLayout.PAGE_END);
        add(panelFacturas, BorderLayout.EAST);

        verificarConexion();
        cargarFacturas();
    }

    private void verificarConexion() {
        Connection conn = DatabaseConnection.getConnection();
        if (conn != null) {
            JOptionPane.showMessageDialog(this, "Conexión exitosa a la base de datos.");
        } else {
            JOptionPane.showMessageDialog(this, "Error al conectar a la base de datos.");
        }
    }

    private void buscarCliente() {
        String identificacion = txtCedulaCliente.getText();
        try {
            Cliente cliente = clienteDAO.getClienteByIdentificacion(identificacion);
            if (cliente != null) {
                txtNombreCliente.setText(cliente.getClinombre());
                txtDireccionCliente.setText(cliente.getClidireccion());
                txtTelefonoCliente.setText(cliente.getClitelefono());
                txtEmailCliente.setText(cliente.getCliemail());
            } else {
                int response = JOptionPane.showConfirmDialog(this, "Cliente no encontrado. ¿Desea crear un nuevo cliente?", "Crear Cliente", JOptionPane.YES_NO_OPTION);
                if (response == JOptionPane.YES_OPTION) {
                    crearCliente();
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al buscar el cliente.");
        }
    }

    private void crearCliente() {
        JTextField txtNuevoNombre = new JTextField();
        JTextField txtNuevoDireccion = new JTextField();
        JTextField txtNuevoTelefono = new JTextField();
        JTextField txtNuevoEmail = new JTextField();
        JTextField txtNuevoTipo = new JTextField();
        JTextField txtNuevoStatus = new JTextField();

        JPanel panel = new JPanel(new GridLayout(7, 2));
        panel.add(new JLabel("Nombre:"));
        panel.add(txtNuevoNombre);
        panel.add(new JLabel("Dirección:"));
        panel.add(txtNuevoDireccion);
        panel.add(new JLabel("Teléfono:"));
        panel.add(txtNuevoTelefono);
        panel.add(new JLabel("Email:"));
        panel.add(txtNuevoEmail);
        panel.add(new JLabel("Tipo:"));
        panel.add(txtNuevoTipo);
        panel.add(new JLabel("Status:"));
        panel.add(txtNuevoStatus);

        int result = JOptionPane.showConfirmDialog(null, panel, "Crear Cliente", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result == JOptionPane.OK_OPTION) {
            Cliente nuevoCliente = new Cliente();
            nuevoCliente.setCliidentificacion(txtCedulaCliente.getText());
            nuevoCliente.setClinombre(txtNuevoNombre.getText());
            nuevoCliente.setClidireccion(txtNuevoDireccion.getText());
            nuevoCliente.setClitelefono(txtNuevoTelefono.getText());
            nuevoCliente.setCliemail(txtNuevoEmail.getText());
            nuevoCliente.setClitipo(txtNuevoTipo.getText());
            nuevoCliente.setClistatus(txtNuevoStatus.getText());

            try {
                clienteDAO.addCliente(nuevoCliente);
                JOptionPane.showMessageDialog(this, "Cliente creado exitosamente.");
                txtNombreCliente.setText(nuevoCliente.getClinombre());
                txtDireccionCliente.setText(nuevoCliente.getClidireccion());
                txtTelefonoCliente.setText(nuevoCliente.getClitelefono());
                txtEmailCliente.setText(nuevoCliente.getCliemail());
            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error al crear el cliente.");
            }
        }
    }

    private void agregarProducto() {
        String codigoProducto = txtCodigoProducto.getText();
        try {
            Producto producto = productoDAO.getProductoByCodigo(codigoProducto);
            if (producto != null) {
                txtNombreProducto.setText(producto.getProdescripcion());
                txtPrecioProducto.setText(String.valueOf(producto.getProprecioum()));
                double cantidad = Double.parseDouble(txtCantidadProducto.getText());
                double precio = producto.getProprecioum();
                double subtotal = cantidad * precio;
                Object[] rowData = {codigoProducto, producto.getProdescripcion(), cantidad, precio, subtotal};
                productosModel.addRow(rowData);
                calcularTotal();
            } else {
                JOptionPane.showMessageDialog(this, "Producto no encontrado.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al buscar el producto.");
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Cantidad no válida.");
        }
    }

    private void calcularTotal() {
        double subtotal = 0.0;
        for (int i = 0; i < productosModel.getRowCount(); i++) {
            subtotal += (double) productosModel.getValueAt(i, 4);
        }
        double iva = subtotal * 0.12; // 12% IVA
        double total = subtotal + iva;
        txtSubtotal.setText(String.valueOf(subtotal));
        txtIva.setText(String.valueOf(iva));
        txtTotal.setText(String.valueOf(total));
    }

    private void guardarFactura() {
        Factura factura = new Factura();
        factura.setFctserie1("001"); // Ajustar según sea necesario
        factura.setFctserie2("001"); // Ajustar según sea necesario

        try {
            // Obtener el nuevo número de factura
            String query = "SELECT generar_numero_factura()";
            Statement statement = DatabaseConnection.getConnection().createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            if (resultSet.next()) {
                String nuevoNumeroFactura = resultSet.getString(1);
                factura.setFctnumfactura(nuevoNumeroFactura.substring(6)); // Los últimos 10 caracteres son el número de factura
            }

            Cliente cliente = new Cliente();
            cliente.setClicodigo(txtCedulaCliente.getText());
            cliente.setClinombre(txtNombreCliente.getText());
            cliente.setCliidentificacion(txtCedulaCliente.getText());
            cliente.setClidireccion(txtDireccionCliente.getText());
            cliente.setClitelefono(txtTelefonoCliente.getText());
            cliente.setCliemail(txtEmailCliente.getText());
            factura.setCliente(cliente);
            factura.setFechaEmision(new java.util.Date());
            factura.setSubtotal(Double.parseDouble(txtSubtotal.getText().replace(",", "")));
            factura.setIva(Double.parseDouble(txtIva.getText().replace(",", "")));
            factura.setTotal(Double.parseDouble(txtTotal.getText().replace(",", "")));

            // Añadir productos a la factura
            List<ProductoFactura> productos = new ArrayList<>();
            for (int i = 0; i < productosModel.getRowCount(); i++) {
                Producto producto = productoDAO.getProductoByCodigo((String) productosModel.getValueAt(i, 0));
                ProductoFactura productoFactura = new ProductoFactura();
                productoFactura.setProducto(producto);
                productoFactura.setCantidad((double) productosModel.getValueAt(i, 2));
                productoFactura.setPrecioUnitario((double) productosModel.getValueAt(i, 3));
                productoFactura.setSubtotal((double) productosModel.getValueAt(i, 4));
                productoFactura.setCostoUnitario(producto.getProcostoum());
                productoFactura.setCostoTotal(productoFactura.getCantidad() * productoFactura.getCostoUnitario());
                productos.add(productoFactura);
            }
            factura.setProductos(productos);

            facturaDAO.addFactura(factura);
            // for (ProductoFactura productoFactura : productos) {
            //     facturaDAO.addProductoFactura(factura.getFctnumfactura(), factura.getFctserie1(), factura.getFctserie2(), productoFactura, cliente.getClicodigo());
            // }
            JOptionPane.showMessageDialog(this, "Factura guardada exitosamente.");
            nuevaFactura();
            cargarFacturas();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al guardar la factura.");
        }
    }

    private void cancelarFactura() {
        int response = JOptionPane.showConfirmDialog(this, "¿Está seguro que desea cancelar la factura?", "Cancelar Factura", JOptionPane.YES_NO_OPTION);
        if (response == JOptionPane.YES_OPTION) {
            nuevaFactura();
        }
    }

    private void nuevaFactura() {
        txtCedulaCliente.setText("");
        txtNombreCliente.setText("");
        txtDireccionCliente.setText("");
        txtTelefonoCliente.setText("");
        txtEmailCliente.setText("");
        txtCodigoProducto.setText("");
        txtNombreProducto.setText("");
        txtCantidadProducto.setText("");
        txtPrecioProducto.setText("");
        txtSubtotal.setText("");
        txtIva.setText("");
        txtTotal.setText("");
        productosModel.setRowCount(0);
        cargarFacturas();
    }

    private void cargarFacturas() {
        try {
            List<Factura> facturas = facturaDAO.getAllFacturas();
            facturasModel.setRowCount(0); // Limpiar tabla antes de cargar nuevas facturas
            for (Factura factura : facturas) {
                Object[] rowData = {factura.getId(), factura.getCliente().getClinombre(), factura.getFechaEmision(), factura.getTotal()};
                facturasModel.addRow(rowData);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al cargar las facturas.");
        }
    }

    private void cargarFactura() {
        int selectedRow = tblFacturas.getSelectedRow();
        if (selectedRow >= 0) {
            int facturaId = (int) facturasModel.getValueAt(selectedRow, 0);
            try {
                Factura factura = facturaDAO.getFacturaById(facturaId);
                if (factura != null) {
                    // Cargar datos del cliente
                    Cliente cliente = factura.getCliente();
                    txtCedulaCliente.setText(cliente.getClicodigo());
                    txtNombreCliente.setText(cliente.getClinombre());
                    txtDireccionCliente.setText(cliente.getClidireccion());
                    txtTelefonoCliente.setText(cliente.getClitelefono());
                    txtEmailCliente.setText(cliente.getCliemail());

                    // Cargar productos de la factura
                    productosModel.setRowCount(0);
                    for (ProductoFactura productoFactura : factura.getProductos()) {
                        Object[] rowData = {
                            productoFactura.getProducto().getProcodigo(),
                            productoFactura.getProducto().getProdescripcion(),
                            productoFactura.getCantidad(),
                            productoFactura.getPrecioUnitario(),
                            productoFactura.getSubtotal()
                        };
                        productosModel.addRow(rowData);
                    }

                    calcularTotal();
                } else {
                    JOptionPane.showMessageDialog(this, "Factura no encontrada.");
                }
            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error al cargar la factura.");
            }
        } else {
            JOptionPane.showMessageDialog(this, "Seleccione una factura de la lista.");
        }
    }

    private void imprimirFactura() {
        int selectedRow = tblFacturas.getSelectedRow();
        if (selectedRow >= 0) {
            int facturaId = (int) facturasModel.getValueAt(selectedRow, 0);
            try {
                Factura factura = facturaDAO.getFacturaById(facturaId);
                if (factura != null) {
                    FacturaPreviewDialog previewDialog = new FacturaPreviewDialog(this, factura);
                    previewDialog.setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(this, "Seleccione una factura válida para imprimir.");
                }
            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error al obtener la factura para imprimir.");
            }
        } else {
            JOptionPane.showMessageDialog(this, "Seleccione una factura de la lista.");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            FacturaGUI frame = new FacturaGUI();
            frame.setVisible(true);
        });
    }
}
