
package comercialpgadmin;
import java.util.Date;
import java.util.List;

public class Factura {
    private int id;
    private String fctserie1;
    private String fctserie2;
    private String fctnumfactura;
    private Cliente cliente;
    private Date fechaEmision;
    private double subtotal;
    private double iva;
    private double total;
    private List<ProductoFactura> productos;

    // Getters y setters

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFctserie1() {
        return fctserie1;
    }

    public void setFctserie1(String fctserie1) {
        this.fctserie1 = fctserie1;
    }

    public String getFctserie2() {
        return fctserie2;
    }

    public void setFctserie2(String fctserie2) {
        this.fctserie2 = fctserie2;
    }

    public String getFctnumfactura() {
        return fctnumfactura;
    }

    public void setFctnumfactura(String fctnumfactura) {
        this.fctnumfactura = fctnumfactura;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Date getFechaEmision() {
        return fechaEmision;
    }

    public void setFechaEmision(Date fechaEmision) {
        this.fechaEmision = fechaEmision;
    }

    public double getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(double subtotal) {
        this.subtotal = subtotal;
    }

    public double getIva() {
        return iva;
    }

    public void setIva(double iva) {
        this.iva = iva;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public List<ProductoFactura> getProductos() {
        return productos;
    }

    public void setProductos(List<ProductoFactura> productos) {
        this.productos = productos;
    }
}
