
package comercialpgadmin;
import javax.swing.*;
import java.awt.*;

public class FacturaPreviewDialog extends JDialog {
    private Factura factura;

    public FacturaPreviewDialog(JFrame parent, Factura factura) {
        super(parent, "Vista Previa de Factura", true);
        this.factura = factura;
        setSize(600, 800);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout());

        JTextArea textArea = new JTextArea();
        textArea.setEditable(false);
        textArea.setText(getFacturaText());
        add(new JScrollPane(textArea), BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        JButton btnImprimir = new JButton("Imprimir");
        btnImprimir.addActionListener(e -> {
            FacturaPrinter printer = new FacturaPrinter(factura);
            printer.printFactura();
        });
        buttonPanel.add(btnImprimir);

        add(buttonPanel, BorderLayout.SOUTH);
    }

    private String getFacturaText() {
        StringBuilder sb = new StringBuilder();
        sb.append("Factura\n");
        sb.append("Cliente: ").append(factura.getCliente().getClinombre()).append("\n");
        sb.append("Cédula/NIT: ").append(factura.getCliente().getCliidentificacion()).append("\n");
        sb.append("Dirección: ").append(factura.getCliente().getClidireccion()).append("\n");
        sb.append("Teléfono: ").append(factura.getCliente().getClitelefono()).append("\n");
        sb.append("Email: ").append(factura.getCliente().getCliemail()).append("\n");
        sb.append("Fecha de Emisión: ").append(factura.getFechaEmision()).append("\n\n");

        sb.append("Productos:\n");
        sb.append(String.format("%-10s%-20s%-10s%-15s%-10s\n", "Código", "Descripción", "Cantidad", "Precio Unitario", "Subtotal"));
        for (ProductoFactura producto : factura.getProductos()) {
            sb.append(String.format("%-10s%-20s%-10s%-15s%-10s\n",
                    producto.getProducto().getProcodigo(),
                    producto.getProducto().getProdescripcion(),
                    producto.getCantidad(),
                    producto.getPrecioUnitario(),
                    producto.getSubtotal()));
        }

        sb.append("\nSubtotal: ").append(factura.getSubtotal()).append("\n");
        sb.append("IVA: ").append(factura.getIva()).append("\n");
        sb.append("Total: ").append(factura.getTotal()).append("\n");

        return sb.toString();
    }
}
