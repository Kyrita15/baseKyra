
package comercialpgadmin;
public class Cliente {
    private String clicodigo;
    private String clinombre;
    private String cliidentificacion;
    private String clidireccion;
    private String clitelefono;
    private String clicelular;
    private String cliemail;
    private String clitipo;
    private String clistatus;

    // Getters y setters

    public String getClicodigo() {
        return clicodigo;
    }

    public void setClicodigo(String clicodigo) {
        this.clicodigo = clicodigo;
    }

    public String getClinombre() {
        return clinombre;
    }

    public void setClinombre(String clinombre) {
        this.clinombre = clinombre;
    }

    public String getCliidentificacion() {
        return cliidentificacion;
    }

    public void setCliidentificacion(String cliidentificacion) {
        this.cliidentificacion = cliidentificacion;
    }

    public String getClidireccion() {
        return clidireccion;
    }

    public void setClidireccion(String clidireccion) {
        this.clidireccion = clidireccion;
    }

    public String getClitelefono() {
        return clitelefono;
    }

    public void setClitelefono(String clitelefono) {
        this.clitelefono = clitelefono;
    }

    public String getClicelular() {
        return clicelular;
    }

    public void setClicelular(String clicelular) {
        this.clicelular = clicelular;
    }

    public String getCliemail() {
        return cliemail;
    }

    public void setCliemail(String cliemail) {
        this.cliemail = cliemail;
    }

    public String getClitipo() {
        return clitipo;
    }

    public void setClitipo(String clitipo) {
        this.clitipo = clitipo;
    }

    public String getClistatus() {
        return clistatus;
    }

    public void setClistatus(String clistatus) {
        this.clistatus = clistatus;
    }
}
