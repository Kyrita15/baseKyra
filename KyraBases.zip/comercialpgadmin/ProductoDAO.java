package comercialpgadmin;
import java.sql.*;

public class ProductoDAO {
    private Connection connection;

    public ProductoDAO() {
        connection = DatabaseConnection.getConnection();
    }

    public Producto getProductoByCodigo(String codigo) throws SQLException {
        String query = "SELECT * FROM PRODUCTOS WHERE PROCODIGO = ?";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, codigo);
        ResultSet resultSet = statement.executeQuery();
        if (resultSet.next()) {
            Producto producto = new Producto();
            producto.setProcodigo(resultSet.getString("PROCODIGO"));
            producto.setProdescripcion(resultSet.getString("PRODESCRIPCION"));
            producto.setProprecioum(resultSet.getDouble("PROPRECIOUM"));
            producto.setProsaldofinal(resultSet.getDouble("PROSALDOFINAL"));
            return producto;
        }
        return null;
    }
}
