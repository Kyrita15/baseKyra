package comercialpgadmin;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FacturaDAO {
    private Connection connection;

    public FacturaDAO() {
        connection = DatabaseConnection.getConnection();
    }

    public List<Factura> getAllFacturas() throws SQLException {
        List<Factura> facturas = new ArrayList<>();
        String query = "SELECT * FROM FACTURAS";
        PreparedStatement statement = connection.prepareStatement(query);
        ResultSet resultSet = statement.executeQuery();
        while (resultSet.next()) {
            Factura factura = new Factura();
            factura.setId(resultSet.getInt("ID_CABECERA"));
            factura.setFctserie1(resultSet.getString("FCTSERIE1"));
            factura.setFctserie2(resultSet.getString("FCTSERIE2"));
            factura.setFctnumfactura(resultSet.getString("FCTNUMFACTURA"));
            Cliente cliente = new ClienteDAO().getClienteByIdentificacion(resultSet.getString("CLICODIGO"));
            factura.setCliente(cliente);
            factura.setFechaEmision(resultSet.getDate("FECHA_EMISION"));
            factura.setSubtotal(resultSet.getDouble("SUBTOTAL"));
            factura.setIva(resultSet.getDouble("IVA"));
            factura.setTotal(resultSet.getDouble("TOTAL"));

            // Obtener productos asociados a la factura
            factura.setProductos(getProductosByFacturaId(factura.getFctnumfactura(), factura.getFctserie1(), factura.getFctserie2()));

            facturas.add(factura);
        }
        return facturas;
    }

    public Factura getFacturaById(int id) throws SQLException {
        String query = "SELECT * FROM FACTURAS WHERE ID_CABECERA = ?";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setInt(1, id);
        ResultSet resultSet = statement.executeQuery();
        if (resultSet.next()) {
            Factura factura = new Factura();
            factura.setId(resultSet.getInt("ID_CABECERA"));
            factura.setFctserie1(resultSet.getString("FCTSERIE1"));
            factura.setFctserie2(resultSet.getString("FCTSERIE2"));
            factura.setFctnumfactura(resultSet.getString("FCTNUMFACTURA"));
            Cliente cliente = new ClienteDAO().getClienteByIdentificacion(resultSet.getString("CLICODIGO"));
            factura.setCliente(cliente);
            factura.setFechaEmision(resultSet.getDate("FECHA_EMISION"));
            factura.setSubtotal(resultSet.getDouble("SUBTOTAL"));
            factura.setIva(resultSet.getDouble("IVA"));
            factura.setTotal(resultSet.getDouble("TOTAL"));
            factura.setProductos(getProductosByFacturaId(factura.getFctnumfactura(), factura.getFctserie1(), factura.getFctserie2()));
            return factura;
        }
        return null;
    }

    public List<ProductoFactura> getProductosByFacturaId(String stonumfactura, String stoserie1, String stoserie2) throws SQLException {
        List<ProductoFactura> productos = new ArrayList<>();
        String query = "SELECT * FROM STODETALLE WHERE STONUMFACTURA = ? AND STOSERIE1 = ? AND STOSERIE2 = ?";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, stonumfactura);
        statement.setString(2, stoserie1);
        statement.setString(3, stoserie2);
        ResultSet resultSet = statement.executeQuery();
        while (resultSet.next()) {
            ProductoFactura productoFactura = new ProductoFactura();
            Producto producto = new ProductoDAO().getProductoByCodigo(resultSet.getString("CODIGO_PRODUCTO"));
            productoFactura.setProducto(producto);
            productoFactura.setCantidad(resultSet.getDouble("CANTIDAD_PRODUCTO"));
            productoFactura.setPrecioUnitario(resultSet.getDouble("PRECIO_UNITARIO"));
            productoFactura.setSubtotal(resultSet.getDouble("PRECIO_TOTAL"));
            productoFactura.setCostoUnitario(resultSet.getDouble("COSTO_UNITARIO"));
            productoFactura.setCostoTotal(resultSet.getDouble("COSTO_TOTAL"));
            productos.add(productoFactura);
        }
        return productos;
    }

    public void addFactura(Factura factura) throws SQLException {
        String query = "INSERT INTO FACTURAS (FCTSERIE1, FCTSERIE2, FCTNUMFACTURA, CLICODIGO, FECHA_EMISION, SUBTOTAL, IVA, TOTAL) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement statement = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
        statement.setString(1, factura.getFctserie1());
        statement.setString(2, factura.getFctserie2());
        statement.setString(3, factura.getFctnumfactura());
        statement.setString(4, factura.getCliente().getClicodigo());
        statement.setDate(5, new java.sql.Date(factura.getFechaEmision().getTime()));
        statement.setDouble(6, factura.getSubtotal());
        statement.setDouble(7, factura.getIva());
        statement.setDouble(8, factura.getTotal());
        statement.executeUpdate();

        ResultSet generatedKeys = statement.getGeneratedKeys();
        if (generatedKeys.next()) {
            int facturaId = generatedKeys.getInt(1);
            for (ProductoFactura productoFactura : factura.getProductos()) {
                addProductoFactura(factura.getFctnumfactura(), factura.getFctserie1(), factura.getFctserie2(), productoFactura, factura.getCliente().getClicodigo());
            }
        }
    }

    public void addProductoFactura(String stonumfactura, String stoserie1, String stoserie2, ProductoFactura productoFactura, String clicodigo) throws SQLException {
        // Obtener PROCOSTOUM de la tabla PRODUCTOS
        String productoQuery = "SELECT PROCOSTOUM FROM PRODUCTOS WHERE PROCODIGO = ?";
        PreparedStatement productoStatement = connection.prepareStatement(productoQuery);
        productoStatement.setString(1, productoFactura.getProducto().getProcodigo());
        ResultSet productoResultSet = productoStatement.executeQuery();
        if (productoResultSet.next()) {
            double procostoum = productoResultSet.getDouble("PROCOSTOUM");

            // Calcular COSTO_TOTAL
            double costoTotal = productoFactura.getCantidad() * procostoum;

            // Insertar en STODETALLE
            String query = "INSERT INTO STODETALLE (STOSERIE1, STOSERIE2, STONUMFACTURA, FECHA_HORA, CODIGO_PRODUCTO, CLICODIGO, CANTIDAD_PRODUCTO, PRECIO_UNITARIO, PRECIO_TOTAL, COSTO_UNITARIO, COSTO_TOTAL) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, stoserie1);
            statement.setString(2, stoserie2);
            statement.setString(3, stonumfactura);
            statement.setTimestamp(4, new Timestamp(System.currentTimeMillis()));
            statement.setString(5, productoFactura.getProducto().getProcodigo());
            statement.setString(6, clicodigo);
            statement.setDouble(7, productoFactura.getCantidad());
            statement.setDouble(8, productoFactura.getPrecioUnitario());
            statement.setDouble(9, productoFactura.getSubtotal());
            statement.setDouble(10, procostoum);
            statement.setDouble(11, costoTotal);
            statement.executeUpdate();
        }
    }
}
