
package comercialpgadmin;
public class Producto {
    private String procodigo;
    private String prodescripcion;
    private String prounidadmedida;
    private double prosaldoinicial;
    private double proingresos;
    private double proegresos;
    private double proajustes;
    private double prosaldofinal;
    private double procostoum;
    private double proprecioum;
    private String prostatus;

    // Getters y Setters
    public String getProcodigo() {
        return procodigo;
    }

    public void setProcodigo(String procodigo) {
        this.procodigo = procodigo;
    }

    public String getProdescripcion() {
        return prodescripcion;
    }

    public void setProdescripcion(String prodescripcion) {
        this.prodescripcion = prodescripcion;
    }

    public String getProunidadmedida() {
        return prounidadmedida;
    }

    public void setProunidadmedida(String prounidadmedida) {
        this.prounidadmedida = prounidadmedida;
    }

    public double getProsaldoinicial() {
        return prosaldoinicial;
    }

    public void setProsaldoinicial(double prosaldoinicial) {
        this.prosaldoinicial = prosaldoinicial;
    }

    public double getProingresos() {
        return proingresos;
    }

    public void setProingresos(double proingresos) {
        this.proingresos = proingresos;
    }

    public double getProegresos() {
        return proegresos;
    }

    public void setProegresos(double proegresos) {
        this.proegresos = proegresos;
    }

    public double getProajustes() {
        return proajustes;
    }

    public void setProajustes(double proajustes) {
        this.proajustes = proajustes;
    }

    public double getProsaldofinal() {
        return prosaldofinal;
    }

    public void setProsaldofinal(double prosaldofinal) {
        this.prosaldofinal = prosaldofinal;
    }

    public double getProcostoum() {
        return procostoum;
    }

    public void setProcostoum(double procostoum) {
        this.procostoum = procostoum;
    }

    public double getProprecioum() {
        return proprecioum;
    }

    public void setProprecioum(double proprecioum) {
        this.proprecioum = proprecioum;
    }

    public String getProstatus() {
        return prostatus;
    }

    public void setProstatus(String prostatus) {
        this.prostatus = prostatus;
    }
}

